package com.rad.center.service;

import com.rad.center.dao.CenterRepository;
import com.rad.center.model.*;
import com.rad.center.util.PasswordUtil;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Business Logic Layer (Service) thực thi toàn bộ 15 Yêu cầu chức năng (FR-01 -> FR-15)
 * và 25 Quy tắc nghiệp vụ (BR-01 -> BR-25) của hệ thống quản lý trung tâm ngoại ngữ.
 */
public class CenterService {
    private final CenterRepository repo;
    private User currentUser;

    public CenterService() {
        this.repo = CenterRepository.getInstance();
        // Mặc định phiên làm việc cho Quản trị viên nếu chạy nhanh
        if (!repo.getUsers().isEmpty()) {
            this.currentUser = repo.getUsers().get(0);
        }
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void setCurrentUser(User currentUser) {
        this.currentUser = currentUser;
    }

    private String todayStr() {
        return new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    }

    private String nowDateTimeStr() {
        return new SimpleDateFormat("yyyy-MM-dd HH:mm").format(new Date());
    }

    // =========================================================================
    // FR-01: ĐĂNG NHẬP VÀ PHÂN QUYỀN (UC-01, NFR-02, NFR-03, NFR-04)
    // =========================================================================
    public User login(String username, String password) throws ValidationException {
        if (username == null || username.trim().isEmpty() || password == null || password.isEmpty()) {
            throw new ValidationException("FR-01", "Vui lòng nhập đầy đủ tên đăng nhập và mật khẩu!");
        }
        String hash = PasswordUtil.sha256(password);
        for (User u : repo.getUsers()) {
            if (u.getUsername().equalsIgnoreCase(username.trim())) {
                if (!u.getPasswordHash().equals(hash)) {
                    throw new ValidationException("FR-01", "Mật khẩu không chính xác!");
                }
                if ("LOCKED".equals(u.getStatus())) {
                    throw new ValidationException("FR-01", "Tài khoản này đã bị khóa, vui lòng liên hệ Quản trị viên!");
                }
                this.currentUser = u;
                return u;
            }
        }
        throw new ValidationException("FR-01", "Tên đăng nhập không tồn tại trong hệ thống!");
    }

    // =========================================================================
    // FR-02: QUẢN LÝ HỌC VIÊN (UC-02, BR-01, BR-08, TC-01, TC-02)
    // =========================================================================
    public List<Student> searchStudents(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return new ArrayList<Student>(repo.getStudents());
        }
        String kw = keyword.trim().toLowerCase();
        List<Student> result = new ArrayList<Student>();
        for (Student s : repo.getStudents()) {
            if (s.getStudentCode().toLowerCase().contains(kw)
                    || s.getFullName().toLowerCase().contains(kw)
                    || s.getPhone().toLowerCase().contains(kw)
                    || s.getEmail().toLowerCase().contains(kw)) {
                result.add(s);
            }
        }
        return result;
    }

    public String generateNextStudentCode() {
        int max = 0;
        for (Student s : repo.getStudents()) {
            if (s.getStudentCode().startsWith("HV")) {
                try {
                    int n = Integer.parseInt(s.getStudentCode().substring(2));
                    if (n > max) max = n;
                } catch (NumberFormatException ignored) {}
            }
        }
        return String.format("HV%03d", max + 1);
    }

    public Student addStudent(String studentCode, String fullName, String dob, String gender,
                              String phone, String email, String address) throws ValidationException {
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new ValidationException("TC-02 / BR-08", "Họ và tên học viên không được để trống!");
        }
        if (phone == null || !phone.trim().matches("^0[0-9]{9,10}$")) {
            throw new ValidationException("TC-02 / FR-02", "Số điện thoại không hợp lệ (phải gồm 10-11 chữ số bắt đầu bằng 0)!");
        }
        if (email == null || !email.trim().contains("@")) {
            throw new ValidationException("TC-02 / FR-02", "Địa chỉ Email không hợp lệ!");
        }
        if (dob == null || !dob.trim().matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            throw new ValidationException("TC-02 / FR-02", "Ngày sinh phải đúng định dạng YYYY-MM-DD!");
        }
        String code = (studentCode == null || studentCode.trim().isEmpty())
                ? generateNextStudentCode() : studentCode.trim().toUpperCase();

        for (Student existing : repo.getStudents()) {
            if (existing.getStudentCode().equalsIgnoreCase(code)) {
                throw new ValidationException("BR-01", "Mã học viên '" + code + "' đã tồn tại trên hệ thống!");
            }
            if (existing.getPhone().equals(phone.trim())) {
                throw new ValidationException("FR-02", "Số điện thoại '" + phone.trim() + "' đã được đăng ký cho học viên " + existing.getFullName() + "!");
            }
        }

        int nextId = repo.getStudents().size() + 1;
        for (Student s : repo.getStudents()) {
            if (s.getStudentId() >= nextId) nextId = s.getStudentId() + 1;
        }

        Student created = new Student(nextId, code, fullName.trim(), dob.trim(),
                gender == null ? "Nam" : gender, phone.trim(), email.trim(),
                address == null ? "" : address.trim(), "ACTIVE", todayStr());
        repo.getStudents().add(created);
        repo.executeMySqlInsertStudent(created);
        repo.saveToDisk();
        return created;
    }

    public Student updateStudent(int studentId, String fullName, String dob, String gender,
                                 String phone, String email, String address, String status) throws ValidationException {
        Student target = repo.findStudentById(studentId);
        if (target == null) {
            throw new ValidationException("FR-02", "Không tìm thấy hồ sơ học viên cần cập nhật!");
        }
        if (fullName == null || fullName.trim().isEmpty()) {
            throw new ValidationException("TC-02", "Họ và tên học viên không được để trống!");
        }
        if (phone == null || !phone.trim().matches("^0[0-9]{9,10}$")) {
            throw new ValidationException("TC-02", "Số điện thoại không hợp lệ!");
        }
        if (email == null || !email.trim().contains("@")) {
            throw new ValidationException("TC-02", "Email không hợp lệ!");
        }
        for (Student other : repo.getStudents()) {
            if (other.getStudentId() != studentId && other.getPhone().equals(phone.trim())) {
                throw new ValidationException("FR-02", "Số điện thoại này đã trùng với học viên " + other.getFullName() + "!");
            }
        }
        target.setFullName(fullName.trim());
        target.setDob(dob.trim());
        target.setGender(gender);
        target.setPhone(phone.trim());
        target.setEmail(email.trim());
        target.setAddress(address == null ? "" : address.trim());
        if (status != null && !status.isEmpty()) {
            target.setStatus(status);
        }
        repo.saveToDisk();
        return target;
    }

    // =========================================================================
    // FR-03, FR-04, FR-05: QUẢN LÝ KHÓA HỌC & LỚP HỌC (UC-03, BR-03 -> BR-07)
    // =========================================================================
    public List<Course> getAllCourses() {
        return new ArrayList<Course>(repo.getCourses());
    }

    public List<Teacher> getAllTeachers() {
        return new ArrayList<Teacher>(repo.getTeachers());
    }

    public List<ClassRoom> getAllClasses() {
        return new ArrayList<ClassRoom>(repo.getClasses());
    }

    public Course addCourse(String courseCode, String courseName, String description,
                            String duration, long tuition, String entryLevel, String status) throws ValidationException {
        if (courseCode == null || courseCode.trim().isEmpty() || courseName == null || courseName.trim().isEmpty()) {
            throw new ValidationException("FR-03", "Mã khóa học và tên khóa học không được để trống!");
        }
        if (tuition < 0) {
            throw new ValidationException("FR-03", "Học phí mặc định không được nhỏ hơn 0!");
        }
        for (Course c : repo.getCourses()) {
            if (c.getCourseCode().equalsIgnoreCase(courseCode.trim())) {
                throw new ValidationException("FR-03", "Mã khóa học '" + courseCode + "' đã tồn tại!");
            }
        }
        int nextId = repo.getCourses().size() + 1;
        Course created = new Course(nextId, courseCode.trim().toUpperCase(), courseName.trim(),
                description == null ? "" : description.trim(),
                duration == null || duration.trim().isEmpty() ? "3 tháng" : duration.trim(),
                tuition, entryLevel == null ? "Mọi trình độ" : entryLevel.trim(),
                status == null ? "ACTIVE" : status);
        repo.getCourses().add(created);
        repo.saveToDisk();
        return created;
    }

    public Course updateCourse(int courseId, String courseName, String description,
                               String duration, long tuition, String entryLevel, String status) throws ValidationException {
        Course c = repo.findCourseById(courseId);
        if (c == null) throw new ValidationException("FR-03", "Không tìm thấy khóa học!");
        if (courseName == null || courseName.trim().isEmpty()) {
            throw new ValidationException("FR-03", "Tên khóa học không được để trống!");
        }
        if (tuition < 0) {
            throw new ValidationException("FR-03", "Học phí không được âm!");
        }
        c.setCourseName(courseName.trim());
        c.setDescription(description == null ? "" : description.trim());
        c.setDuration(duration.trim());
        c.setTuition(tuition);
        c.setEntryLevel(entryLevel.trim());
        c.setStatus(status);
        repo.saveToDisk();
        return c;
    }

    /**
     * Đếm sĩ số hiện tại của lớp (chỉ tính các đăng ký có trạng thái CONFIRMED theo BR-12).
     */
    public int getConfirmedEnrollmentCount(int classId) {
        int count = 0;
        for (Enrollment e : repo.getEnrollments()) {
            if (e.getClassId() == classId && "CONFIRMED".equals(e.getStatus())) {
                count++;
            }
        }
        return count;
    }

    public ClassRoom addClassRoom(String classCode, int courseId, int teacherId, int capacity,
                                  String startDate, String endDate, String scheduleSummary,
                                  String room, String status) throws ValidationException {
        if (classCode == null || classCode.trim().isEmpty()) {
            throw new ValidationException("FR-04", "Mã lớp học không được để trống!");
        }
        if (capacity <= 0) {
            throw new ValidationException("BR-05", "Sĩ số tối đa của lớp phải lớn hơn 0!");
        }
        Course course = repo.findCourseById(courseId);
        if (course == null) {
            throw new ValidationException("BR-04", "Khóa học trực thuộc không tồn tại!");
        }
        Teacher teacher = repo.findTeacherById(teacherId);
        if (teacher == null) {
            throw new ValidationException("FR-05", "Giảng viên phụ trách không tồn tại!");
        }
        if (startDate == null || endDate == null || startDate.compareTo(endDate) > 0) {
            throw new ValidationException("FR-04", "Ngày kết thúc lớp học phải sau ngày bắt đầu!");
        }
        String cleanCode = classCode.trim().toUpperCase();
        for (ClassRoom existing : repo.getClasses()) {
            if (existing.getClassCode().equalsIgnoreCase(cleanCode)) {
                throw new ValidationException("FR-04", "Mã lớp '" + cleanCode + "' đã tồn tại!");
            }
            // BR-07: Kiểm tra trùng lịch giảng viên đối với các lớp đang mở
            if (existing.getTeacherId() == teacherId
                    && ("OPEN".equals(existing.getStatus()) || "ONGOING".equals(existing.getStatus()))
                    && existing.getScheduleSummary().equalsIgnoreCase(scheduleSummary.trim())) {
                throw new ValidationException("BR-07", "Giảng viên " + teacher.getFullName()
                        + " đã được phân công dạy lớp " + existing.getClassCode()
                        + " trùng lịch (" + scheduleSummary + ")!");
            }
        }

        int nextId = repo.getClasses().size() + 1;
        for (ClassRoom c : repo.getClasses()) if (c.getClassId() >= nextId) nextId = c.getClassId() + 1;

        ClassRoom created = new ClassRoom(nextId, cleanCode, courseId, teacherId, capacity,
                startDate.trim(), endDate.trim(), scheduleSummary.trim(),
                room == null || room.trim().isEmpty() ? "P.201" : room.trim(),
                status == null ? "OPEN" : status);
        repo.getClasses().add(created);
        repo.saveToDisk();
        return created;
    }

    public ClassRoom updateClassRoom(int classId, int courseId, int teacherId, int capacity,
                                     String startDate, String endDate, String scheduleSummary,
                                     String room, String status) throws ValidationException {
        ClassRoom target = repo.findClassById(classId);
        if (target == null) {
            throw new ValidationException("FR-04", "Không tìm thấy lớp học cần cập nhật!");
        }
        if (capacity <= 0) {
            throw new ValidationException("BR-05", "Sĩ số tối đa phải lớn hơn 0!");
        }
        int currentEnrolled = getConfirmedEnrollmentCount(classId);
        if (capacity < currentEnrolled) {
            throw new ValidationException("FR-04 / BR-06", "Không thể giảm sĩ số tối đa (" + capacity
                    + ") xuống thấp hơn số học viên đang đăng ký hiệu lực (" + currentEnrolled + ")!");
        }
        Teacher teacher = repo.findTeacherById(teacherId);
        for (ClassRoom other : repo.getClasses()) {
            if (other.getClassId() != classId
                    && other.getTeacherId() == teacherId
                    && ("OPEN".equals(other.getStatus()) || "ONGOING".equals(other.getStatus()))
                    && ("OPEN".equals(status) || "ONGOING".equals(status))
                    && other.getScheduleSummary().equalsIgnoreCase(scheduleSummary.trim())) {
                throw new ValidationException("BR-07", "Giảng viên " + (teacher != null ? teacher.getFullName() : "")
                        + " bị trùng lịch với lớp " + other.getClassCode() + "!");
            }
        }
        target.setCourseId(courseId);
        target.setTeacherId(teacherId);
        target.setCapacity(capacity);
        target.setStartDate(startDate.trim());
        target.setEndDate(endDate.trim());
        target.setScheduleSummary(scheduleSummary.trim());
        target.setRoom(room.trim());
        target.setStatus(status);
        repo.saveToDisk();
        return target;
    }

    // =========================================================================
    // FR-06, FR-07, FR-08, FR-09: ĐĂNG KÝ LỚP HỌC & TỰ ĐỘNG TẠO HỌC PHÍ
    // (UC-04, BR-08 -> BR-15, TC-03, TC-04, TC-05)
    // =========================================================================
    public List<Enrollment> getAllEnrollments() {
        return new ArrayList<Enrollment>(repo.getEnrollments());
    }

    public Enrollment enrollStudent(int studentId, int classId) throws ValidationException {
        // BR-08: Học viên phải có hồ sơ hợp lệ trước khi đăng ký
        Student student = repo.findStudentById(studentId);
        if (student == null || !"ACTIVE".equals(student.getStatus())) {
            throw new ValidationException("BR-08", "Học viên không tồn tại hoặc hồ sơ đã ngừng hoạt động!");
        }

        // BR-09: Chỉ lớp đang cho phép đăng ký (OPEN) mới tiếp nhận học viên
        ClassRoom clazz = repo.findClassById(classId);
        if (clazz == null) {
            throw new ValidationException("FR-07", "Lớp học không tồn tại!");
        }
        if (!"OPEN".equals(clazz.getStatus())) {
            throw new ValidationException("BR-09", "Lớp " + clazz.getClassCode()
                    + " hiện ở trạng thái '" + clazz.getStatus() + "', không tiếp nhận đăng ký mới!");
        }

        // BR-10 & TC-05: Một học viên không được có hai đăng ký còn hiệu lực trong cùng lớp
        for (Enrollment e : repo.getEnrollments()) {
            if (e.getStudentId() == studentId && e.getClassId() == classId && "CONFIRMED".equals(e.getStatus())) {
                throw new ValidationException("TC-05 / BR-10", "Học viên " + student.getFullName()
                        + " đã có đăng ký hợp lệ (" + e.getEnrollmentCode() + ") trong lớp " + clazz.getClassCode() + "!");
            }
        }

        // BR-06 & TC-04: Kiểm tra sĩ số tối đa
        int currentCount = getConfirmedEnrollmentCount(classId);
        if (currentCount >= clazz.getCapacity()) {
            throw new ValidationException("TC-04 / BR-06", "Lớp " + clazz.getClassCode()
                    + " đã đủ sĩ số tối đa (" + currentCount + "/" + clazz.getCapacity() + "). Hệ thống từ chối đăng ký!");
        }

        // Tạo bản ghi đăng ký + nghĩa vụ học phí trong cùng giao dịch (FR-06, FR-09, BR-11, BR-14, BR-15)
        int nextEnrollmentId = repo.getEnrollments().size() + 1;
        for (Enrollment e : repo.getEnrollments()) {
            if (e.getEnrollmentId() >= nextEnrollmentId) nextEnrollmentId = e.getEnrollmentId() + 1;
        }
        String enrollCode = String.format("DK%03d", nextEnrollmentId);
        String staffName = currentUser != null ? currentUser.getFullName() : "Nhân viên đào tạo";

        Enrollment enrollment = new Enrollment(
                nextEnrollmentId, enrollCode, studentId, classId, todayStr(), staffName, "CONFIRMED", ""
        );

        Course course = repo.findCourseById(clazz.getCourseId());
        long tuitionAmount = (course != null) ? course.getTuition() : 3000000L;

        int nextTuitionId = repo.getTuitionFees().size() + 1;
        for (TuitionFee tf : repo.getTuitionFees()) {
            if (tf.getTuitionId() >= nextTuitionId) nextTuitionId = tf.getTuitionId() + 1;
        }
        TuitionFee tuitionFee = new TuitionFee(nextTuitionId, nextEnrollmentId, tuitionAmount, todayStr(), "UNPAID");

        repo.getEnrollments().add(enrollment);
        repo.getTuitionFees().add(tuitionFee);
        repo.saveToDisk();
        return enrollment;
    }

    public void cancelEnrollment(int enrollmentId, String reason) throws ValidationException {
        Enrollment enrollment = repo.findEnrollmentById(enrollmentId);
        if (enrollment == null) {
            throw new ValidationException("FR-08", "Không tìm thấy bản ghi đăng ký!");
        }
        if ("CANCELLED".equals(enrollment.getStatus())) {
            throw new ValidationException("FR-08", "Đăng ký này đã ở trạng thái hủy từ trước!");
        }
        // BR-12 & BR-13: Hủy đăng ký giải phóng sĩ số nhưng KHÔNG tự động xóa lịch sử thanh toán
        enrollment.setStatus("CANCELLED");
        enrollment.setCancelReason(reason == null || reason.trim().isEmpty() ? "Học viên xin hủy lớp" : reason.trim());
        repo.saveToDisk();
    }

    // =========================================================================
    // FR-10, FR-11: QUẢN LÝ HỌC PHÍ & THANH TOÁN (UC-05, BR-16 -> BR-19, TC-06, TC-07)
    // =========================================================================
    public List<TuitionFee> getAllTuitionFees() {
        return new ArrayList<TuitionFee>(repo.getTuitionFees());
    }

    public List<Payment> getPaymentsByTuitionId(int tuitionId) {
        List<Payment> list = new ArrayList<Payment>();
        for (Payment p : repo.getPayments()) {
            if (p.getTuitionId() == tuitionId) {
                list.add(p);
            }
        }
        return list;
    }

    public List<Payment> getAllPayments() {
        return new ArrayList<Payment>(repo.getPayments());
    }

    public long getTotalPaidForTuition(int tuitionId) {
        long sum = 0L;
        for (Payment p : repo.getPayments()) {
            if (p.getTuitionId() == tuitionId) {
                sum += p.getAmount();
            }
        }
        return sum;
    }

    /**
     * BR-19: Công nợ = Học phí phải thu - Tổng thanh toán hợp lệ
     */
    public long getRemainingDebt(int tuitionId) {
        TuitionFee tf = repo.findTuitionById(tuitionId);
        if (tf == null) return 0L;
        long rem = tf.getAmountDue() - getTotalPaidForTuition(tuitionId);
        return Math.max(0L, rem);
    }

    public Payment recordPayment(int tuitionId, long amount, String method, String note) throws ValidationException {
        TuitionFee tf = repo.findTuitionById(tuitionId);
        if (tf == null) {
            throw new ValidationException("FR-10", "Không tìm thấy khoản nghĩa vụ học phí cần thanh toán!");
        }
        // BR-17: Số tiền thanh toán phải lớn hơn 0
        if (amount <= 0) {
            throw new ValidationException("BR-17", "Số tiền thanh toán phải lớn hơn 0 VNĐ!");
        }
        // BR-18 & TC-07: Tổng thanh toán hợp lệ không vượt số tiền phải thu (không vượt công nợ còn lại)
        long remainingDebt = getRemainingDebt(tuitionId);
        if (remainingDebt == 0) {
            throw new ValidationException("BR-18", "Khoản học phí này đã được thanh toán đủ 100%, không còn công nợ!");
        }
        if (amount > remainingDebt) {
            throw new ValidationException("TC-07 / BR-18", "Số tiền thanh toán (" + amount
                    + " VNĐ) vượt quá số tiền còn nợ (" + remainingDebt + " VNĐ)!");
        }

        int nextPayId = repo.getPayments().size() + 1;
        for (Payment p : repo.getPayments()) {
            if (p.getPaymentId() >= nextPayId) nextPayId = p.getPaymentId() + 1;
        }
        String payCode = String.format("PT%03d", nextPayId);
        String cashier = currentUser != null ? currentUser.getFullName() : "Nhân viên thu ngân";

        Payment payment = new Payment(nextPayId, payCode, tuitionId, amount, todayStr(),
                method == null ? "CASH" : method, cashier, note == null ? "" : note.trim());
        repo.getPayments().add(payment);

        // Cập nhật trạng thái nghĩa vụ học phí
        long newDebt = getRemainingDebt(tuitionId);
        if (newDebt == 0) {
            tf.setStatus("PAID");
        } else {
            tf.setStatus("PARTIAL");
        }

        repo.saveToDisk();
        return payment;
    }

    // =========================================================================
    // FR-12, FR-13, FR-14: QUẢN LÝ BUỔI HỌC & ĐIỂM DANH HỌC VIÊN
    // (UC-06, BR-20 -> BR-25, TC-08, TC-09, TC-10)
    // =========================================================================
    public List<Session> getSessionsByClass(int classId) {
        List<Session> list = new ArrayList<Session>();
        for (Session s : repo.getSessions()) {
            if (s.getClassId() == classId) {
                list.add(s);
            }
        }
        return list;
    }

    public Session addSession(int classId, String topic, String sessionDate, String startTime, String endTime) throws ValidationException {
        ClassRoom clazz = repo.findClassById(classId);
        if (clazz == null) {
            throw new ValidationException("BR-20", "Lớp học không tồn tại!");
        }
        if (topic == null || topic.trim().isEmpty()) {
            throw new ValidationException("FR-12", "Chủ đề buổi học không được để trống!");
        }
        if (sessionDate == null || !sessionDate.trim().matches("^\\d{4}-\\d{2}-\\d{2}$")) {
            throw new ValidationException("FR-12", "Ngày học phải đúng định dạng YYYY-MM-DD!");
        }
        List<Session> classSessions = getSessionsByClass(classId);
        for (Session existing : classSessions) {
            if (existing.getSessionDate().equals(sessionDate.trim())
                    && existing.getStartTime().equals(startTime.trim())) {
                throw new ValidationException("FR-12", "Lớp " + clazz.getClassCode()
                        + " đã có buổi học vào ngày " + sessionDate + " lúc " + startTime + "!");
            }
        }
        int nextId = repo.getSessions().size() + 1;
        for (Session s : repo.getSessions()) if (s.getSessionId() >= nextId) nextId = s.getSessionId() + 1;
        int nextNum = classSessions.size() + 1;

        Session created = new Session(nextId, classId, nextNum, topic.trim(),
                sessionDate.trim(), startTime.trim(), endTime.trim(), "SCHEDULED");
        repo.getSessions().add(created);
        repo.saveToDisk();
        return created;
    }

    /**
     * BR-21: Chỉ học viên có đăng ký hợp lệ (CONFIRMED) tại lớp mới nằm trong danh sách điểm danh.
     */
    public List<Student> getEligibleStudentsForClass(int classId) {
        List<Student> list = new ArrayList<Student>();
        for (Enrollment e : repo.getEnrollments()) {
            if (e.getClassId() == classId && "CONFIRMED".equals(e.getStatus())) {
                Student s = repo.findStudentById(e.getStudentId());
                if (s != null) {
                    list.add(s);
                }
            }
        }
        return list;
    }

    public Attendance getAttendanceRecord(int sessionId, int studentId) {
        for (Attendance a : repo.getAttendances()) {
            if (a.getSessionId() == sessionId && a.getStudentId() == studentId) {
                return a;
            }
        }
        return null;
    }

    /**
     * FR-13, BR-22, TC-08, TC-09: Lưu hoặc cập nhật điểm danh.
     * Mỗi học viên chỉ có tối đa 1 bản ghi điểm danh cho mỗi buổi học (UNIQUE session_id + student_id).
     */
    public Attendance markAttendance(int sessionId, int studentId, String status, String note) throws ValidationException {
        Session session = repo.findSessionById(sessionId);
        if (session == null) {
            throw new ValidationException("UC-06 / E2", "Buổi học không tồn tại!");
        }
        if (!"PRESENT".equals(status) && !"ABSENT_EXCUSED".equals(status) && !"ABSENT_UNEXCUSED".equals(status)) {
            throw new ValidationException("BR-24", "Trạng thái điểm danh không hợp lệ!");
        }
        // Kiểm tra học viên có đăng ký CONFIRMED trong lớp của buổi học không (BR-21)
        boolean eligible = false;
        for (Enrollment e : repo.getEnrollments()) {
            if (e.getClassId() == session.getClassId()
                    && e.getStudentId() == studentId
                    && "CONFIRMED".equals(e.getStatus())) {
                eligible = true;
                break;
            }
        }
        if (!eligible) {
            throw new ValidationException("BR-21", "Học viên không có đăng ký hợp lệ trong lớp của buổi học này!");
        }

        String marker = currentUser != null ? currentUser.getFullName() : "Giảng viên";
        Attendance existing = getAttendanceRecord(sessionId, studentId);
        if (existing != null) {
            // TC-09: Điểm danh trùng buổi -> Cập nhật bản ghi hiện có, tuyệt đối không tạo bản ghi trùng
            existing.setStatus(status);
            existing.setMarkedBy(marker);
            existing.setMarkedAt(nowDateTimeStr());
            existing.setNote(note == null ? "" : note.trim());
            session.setStatus("COMPLETED");
            repo.saveToDisk();
            return existing;
        } else {
            int nextId = repo.getAttendances().size() + 1;
            for (Attendance a : repo.getAttendances()) {
                if (a.getAttendanceId() >= nextId) nextId = a.getAttendanceId() + 1;
            }
            Attendance created = new Attendance(nextId, sessionId, studentId, status,
                    marker, nowDateTimeStr(), note == null ? "" : note.trim());
            repo.getAttendances().add(created);
            session.setStatus("COMPLETED");
            repo.saveToDisk();
            return created;
        }
    }

    /**
     * FR-14 & BR-25: Tính tỷ lệ chuyên cần của học viên trong lớp (% số buổi PRESENT / tổng số buổi đã điểm danh).
     */
    public double calculateStudentAttendanceRate(int classId, int studentId) {
        List<Session> sessions = getSessionsByClass(classId);
        int totalMarked = 0;
        int presentCount = 0;
        for (Session s : sessions) {
            Attendance a = getAttendanceRecord(s.getSessionId(), studentId);
            if (a != null) {
                totalMarked++;
                if ("PRESENT".equals(a.getStatus())) {
                    presentCount++;
                }
            }
        }
        if (totalMarked == 0) return 0.0;
        return (presentCount * 100.0) / totalMarked;
    }

    // =========================================================================
    // FR-15: THỐNG KÊ TỔNG HỢP (UC-07)
    // =========================================================================
    public long getTotalTuitionDueAll() {
        long total = 0L;
        for (TuitionFee tf : repo.getTuitionFees()) {
            Enrollment e = repo.findEnrollmentById(tf.getEnrollmentId());
            if (e != null && !"CANCELLED".equals(e.getStatus())) {
                total += tf.getAmountDue();
            }
        }
        return total;
    }

    public long getTotalCollectedAll() {
        long total = 0L;
        for (Payment p : repo.getPayments()) {
            total += p.getAmount();
        }
        return total;
    }

    public long getTotalDebtAll() {
        long debt = 0L;
        for (TuitionFee tf : repo.getTuitionFees()) {
            Enrollment e = repo.findEnrollmentById(tf.getEnrollmentId());
            if (e != null && !"CANCELLED".equals(e.getStatus())) {
                debt += getRemainingDebt(tf.getTuitionId());
            }
        }
        return debt;
    }
}
