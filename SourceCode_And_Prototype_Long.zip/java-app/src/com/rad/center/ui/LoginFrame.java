package com.rad.center.ui;

import com.rad.center.model.User;
import com.rad.center.service.CenterService;
import com.rad.center.service.ValidationException;
import com.rad.center.util.DatabaseConfig;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * Màn hình 1 – Đăng nhập & Phân quyền Hệ thống (FR-01, UC-01, NFR-02, NFR-03, NFR-04)
 */
public class LoginFrame extends JFrame {
    private final CenterService service;
    private final JTextField txtUsername = UITheme.createTextField(20);
    private final JPasswordField txtPassword = new JPasswordField(20);

    public LoginFrame(final CenterService service) {
        this.service = service;
        setTitle("Đăng nhập Hệ thống Quản lý Trung tâm Ngoại ngữ (RAD - 502050)");
        setSize(920, 560);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
        setLayout(new GridLayout(1, 2));

        // Left Banner Panel
        JPanel leftPanel = new JPanel(new BorderLayout(16, 16));
        leftPanel.setBackground(UITheme.SIDEBAR_BG);
        leftPanel.setBorder(new EmptyBorder(40, 36, 40, 36));

        JPanel brandInfo = new JPanel(new GridLayout(6, 1, 6, 6));
        brandInfo.setOpaque(false);
        JLabel l1 = new JLabel("TRƯỜNG ĐH TÔN ĐỨC THẮNG");
        l1.setFont(new Font("SansSerif", Font.BOLD, 14));
        l1.setForeground(new Color(56, 189, 248));

        JLabel l2 = new JLabel("HỆ THỐNG QUẢN LÝ");
        l2.setFont(new Font("SansSerif", Font.BOLD, 24));
        l2.setForeground(Color.WHITE);

        JLabel l3 = new JLabel("TRUNG TÂM NGOẠI NGỮ");
        l3.setFont(new Font("SansSerif", Font.BOLD, 24));
        l3.setForeground(Color.WHITE);

        JLabel l4 = new JLabel("Học phần: Phân tích và Thiết kế Yêu cầu (502050)");
        l4.setFont(UITheme.FONT_REGULAR);
        l4.setForeground(new Color(203, 213, 225));

        JLabel l5 = new JLabel("Nhóm thực hiện: Phúc – Hoàn – Long");
        l5.setFont(UITheme.FONT_BOLD);
        l5.setForeground(new Color(16, 185, 129));

        JLabel l6 = new JLabel("Kiến trúc: Java Swing -> Service -> DAO -> MySQL");
        l6.setFont(UITheme.FONT_SMALL);
        l6.setForeground(new Color(148, 163, 184));

        brandInfo.add(l1);
        brandInfo.add(l2);
        brandInfo.add(l3);
        brandInfo.add(l4);
        brandInfo.add(l5);
        brandInfo.add(l6);
        leftPanel.add(brandInfo, BorderLayout.NORTH);

        JTextArea featureSummary = new JTextArea(
                "5 CHỨC NĂNG JAVA TRỌNG TÂM:\n"
                        + "1. Quản lý Hồ sơ Học viên (FR-02)\n"
                        + "2. Quản lý Khóa học & Lớp học (FR-03, FR-04)\n"
                        + "3. Đăng ký Lớp học & Kiểm tra Sĩ số (FR-06, FR-07)\n"
                        + "4. Thu Học phí & Quản lý Công nợ (FR-09, FR-10)\n"
                        + "5. Điểm danh Học viên & Chuyên cần (FR-13, FR-14)\n\n"
                        + "Trạng thái CSDL:\n" + DatabaseConfig.getConnectionSummary()
        );
        featureSummary.setEditable(false);
        featureSummary.setOpaque(false);
        featureSummary.setForeground(new Color(226, 232, 240));
        featureSummary.setFont(UITheme.FONT_REGULAR);
        leftPanel.add(featureSummary, BorderLayout.CENTER);

        // Right Login Form Panel
        JPanel rightPanel = new JPanel(new BorderLayout(12, 12));
        rightPanel.setBackground(Color.WHITE);
        rightPanel.setBorder(new EmptyBorder(36, 40, 36, 40));

        JLabel formTitle = new JLabel("ĐĂNG NHẬP HỆ THỐNG (UC-01)");
        formTitle.setFont(UITheme.FONT_TITLE);
        formTitle.setForeground(UITheme.TEXT_DARK);
        rightPanel.add(formTitle, BorderLayout.NORTH);

        JPanel formCenter = new JPanel(new GridLayout(6, 1, 6, 6));
        formCenter.setOpaque(false);

        txtUsername.setText("admin");
        txtPassword.setText("123456");
        txtPassword.setFont(UITheme.FONT_REGULAR);
        txtPassword.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(UITheme.BORDER_COLOR, 1),
                new EmptyBorder(6, 8, 6, 8)
        ));

        JLabel lblU = new JLabel("Tên đăng nhập (*):");
        lblU.setFont(UITheme.FONT_BOLD);
        JLabel lblP = new JLabel("Mật khẩu (* - Băm SHA-256 theo NFR-03):");
        lblP.setFont(UITheme.FONT_BOLD);

        JButton btnLogin = UITheme.createButton("ĐĂNG NHẬP VÀO HỆ THỐNG", UITheme.PRIMARY, Color.WHITE);

        formCenter.add(lblU);
        formCenter.add(txtUsername);
        formCenter.add(lblP);
        formCenter.add(txtPassword);
        formCenter.add(new JLabel(""));
        formCenter.add(btnLogin);
        rightPanel.add(formCenter, BorderLayout.CENTER);

        // Quick Role Selector for Demo
        JPanel quickDemoPanel = new JPanel(new GridLayout(3, 2, 8, 8));
        quickDemoPanel.setOpaque(false);
        quickDemoPanel.setBorder(BorderFactory.createTitledBorder("Chọn nhanh Tài khoản Demo theo Vai trò (Mật khẩu: 123456)"));

        JButton btnRoleAdmin = UITheme.createButton("Quản trị (Long)", new Color(241, 245, 249), UITheme.TEXT_DARK);
        JButton btnRoleTraining = UITheme.createButton("Đào tạo (Phúc)", new Color(241, 245, 249), UITheme.TEXT_DARK);
        JButton btnRoleCashier = UITheme.createButton("Thu ngân (Hoàn)", new Color(241, 245, 249), UITheme.TEXT_DARK);
        JButton btnRoleTeacher = UITheme.createButton("Giảng viên (Tuấn)", new Color(241, 245, 249), UITheme.TEXT_DARK);

        quickDemoPanel.add(btnRoleAdmin);
        quickDemoPanel.add(btnRoleTraining);
        quickDemoPanel.add(btnRoleCashier);
        quickDemoPanel.add(btnRoleTeacher);
        rightPanel.add(quickDemoPanel, BorderLayout.SOUTH);

        add(leftPanel);
        add(rightPanel);

        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                doLogin();
            }
        });

        btnRoleAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtUsername.setText("admin");
                txtPassword.setText("123456");
            }
        });
        btnRoleTraining.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtUsername.setText("daotao");
                txtPassword.setText("123456");
            }
        });
        btnRoleCashier.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtUsername.setText("thungan");
                txtPassword.setText("123456");
            }
        });
        btnRoleTeacher.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtUsername.setText("giangvien");
                txtPassword.setText("123456");
            }
        });
    }

    private void doLogin() {
        try {
            User user = service.login(txtUsername.getText(), new String(txtPassword.getPassword()));
            dispose();
            MainFrame mainFrame = new MainFrame(service);
            mainFrame.setVisible(true);
        } catch (ValidationException ex) {
            JOptionPane.showMessageDialog(this,
                    "[" + ex.getRuleCode() + "] " + ex.getMessage(),
                    "Đăng nhập thất bại", JOptionPane.ERROR_MESSAGE);
        }
    }
}
