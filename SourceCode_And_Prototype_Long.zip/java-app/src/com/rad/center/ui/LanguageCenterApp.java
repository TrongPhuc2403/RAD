package com.rad.center.ui;

import com.rad.center.service.CenterService;

import javax.swing.*;

/**
 * Điểm khởi chạy chính của chương trình Java Swing (Mục 3.2 Đề thi cuối kỳ).
 */
public class LanguageCenterApp {
    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        final CenterService service = new CenterService();

        // Nếu truyền tham số --direct thì vào thẳng MainFrame để demo nhanh
        if (args.length > 0 && "--direct".equalsIgnoreCase(args[0])) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new MainFrame(service).setVisible(true);
                }
            });
        } else {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    new LoginFrame(service).setVisible(true);
                }
            });
        }
    }
}
