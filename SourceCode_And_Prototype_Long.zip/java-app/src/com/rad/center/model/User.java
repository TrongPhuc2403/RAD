package com.rad.center.model;

import java.io.Serializable;

public class User implements Serializable {
    private static final long serialVersionUID = 1L;
    private int userId;
    private String username;
    private String passwordHash;
    private String fullName;
    private String role; // ADMIN, TRAINING_STAFF, CASHIER, TEACHER, STUDENT
    private String status; // ACTIVE, LOCKED

    public User() {}

    public User(int userId, String username, String passwordHash, String fullName, String role, String status) {
        this.userId = userId;
        this.username = username;
        this.passwordHash = passwordHash;
        this.fullName = fullName;
        this.role = role;
        this.status = status;
    }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getRoleDisplay() {
        if ("ADMIN".equals(role)) return "Quản trị viên";
        if ("TRAINING_STAFF".equals(role)) return "Nhân viên đào tạo";
        if ("CASHIER".equals(role)) return "Nhân viên thu ngân";
        if ("TEACHER".equals(role)) return "Giảng viên";
        if ("STUDENT".equals(role)) return "Học viên";
        return role;
    }
}
